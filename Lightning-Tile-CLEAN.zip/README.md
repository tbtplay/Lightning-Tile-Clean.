# Lightning Tile

Quick Settings tile for Infinix/XOS Lightning Multi-Window.

The tile uses Shizuku to run:
`service call activity_task 178`

Requirements:
- Android 11+
- Shizuku running
- Lightning Tile authorized in Shizuku

GitHub Actions builds the debug APK.
