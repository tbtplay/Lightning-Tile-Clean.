package com.example.lightningtile;

import android.content.pm.PackageManager;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import android.widget.Toast;

import rikka.shizuku.Shizuku;

public class LightningTileService extends TileService {

    @Override
    public void onStartListening() {
        super.onStartListening();

        Tile tile = getQsTile();
        if (tile != null) {
            tile.setLabel("Lightning");
            tile.setState(Tile.STATE_INACTIVE);
            tile.updateTile();
        }
    }

    @Override
    public void onClick() {
        super.onClick();

        if (!Shizuku.pingBinder()) {
            showMessage("Shizuku is not running");
            return;
        }

        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            showMessage("Allow Lightning Tile in Shizuku");
            return;
        }

        try {
            Shizuku.newProcess(
                    new String[]{"sh", "-c", "service call activity_task 178"},
                    null,
                    null
            );
        } catch (Exception e) {
            showMessage("Could not trigger Lightning");
        }
    }

    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
